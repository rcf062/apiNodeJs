# apiNodeJs
Crud criado com NodeJs, usando a biblioteca nodemoon e body parser
